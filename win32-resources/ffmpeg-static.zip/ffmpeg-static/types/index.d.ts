declare const ffmpegPath: string | null;
export default ffmpegPath;
